import MoviesData from "./Movies";

export default function App() {
  return (
    <div>
      <MoviesData />
    </div>
  );
}
