import React, { useState, useEffect } from "react";
import "./styles.css";

export default function MoviesData() {
  const [Movies, fetchMovies] = useState([]);

  const getData = () => {
    fetch("http://localhost:3000/movies.json")
      .then((response) => {
        if (!response.ok) {
          throw new Error("HTTP error " + response.status);
        }
        return response.json();
      })
      .then((json) => {
        console.log(json.Movies);
        fetchMovies(json.Movies);
      });
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <>
      {Movies.map((item, i) => {
        return (
          <div class="col-sm-3">
            <div class="thumb-wrapper">
              <span class="wish-icon">
                <i class="fa fa-heart-o"></i>
              </span>
              <div class="img-box">
                <img src={item.Image} class="img-fluid" alt="Headphone" />
              </div>
              <div class="thumb-content">
                <h4>{item.Name}</h4>
                <div class="star-rating">
                  <ul class="list-inline">
                    <li class="list-inline-item">
                      <i class="fa fa-star"></i>
                    </li>
                    <li class="list-inline-item">
                      <i class="fa fa-star"></i>
                    </li>
                    <li class="list-inline-item">
                      <i class="fa fa-star"></i>
                    </li>
                    <li class="list-inline-item">
                      <i class="fa fa-star"></i>
                    </li>
                    <li class="list-inline-item">
                      <i class="fa fa-star-o"></i>
                    </li>
                  </ul>
                </div>
                <p class="item-price">
                  <strike>{item.ReducedPrice} kr</strike>{" "}
                  <b>{item.ActualPrice} kr </b>
                </p>
                <a href="#" class="btn btn-primary">
                  Add to Cart
                </a>
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
}
